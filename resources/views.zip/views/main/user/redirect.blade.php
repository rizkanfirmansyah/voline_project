@extends('templates.dashboard')

@section('main')

<div class="header pb-6 d-flex align-items-center" style="min-height: 500px;  background-size: cover; background-position: center top;">
    <!-- Mask -->

  </div>

  <div class="container-fluid mt--7">
    <div class="row" id="Redirect" data-toggle="redirect">

    </div>

@endsection
