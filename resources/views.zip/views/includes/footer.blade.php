   <!-- Footer -->
   <footer class="footer pt-5">
    <div class="row align-items-center justify-content-lg-between">
      <div class="col-lg-6">
        <div class="copyright text-center  text-lg-left  text-muted">
          {{-- &copy; 2020 Voline --}}
        </div>
      </div>
    </div>
  </footer>
@include('includes.js')

</body>

</html>
