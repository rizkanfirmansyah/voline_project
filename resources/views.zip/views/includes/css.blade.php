<!-- Favicon -->
<link rel="icon" href="/assets/img/brand/favicon.png" type="image/png">
<!-- Fonts -->
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700">
<!-- Icons -->
<link rel="stylesheet" href="/assets/vendor/nucleo/css/nucleo.css" type="text/css">
<link rel="stylesheet" href="/assets/vendor/sweetalert/dist/sweetalert.min.css" type="text/css">
<link rel="stylesheet" href="/assets/vendor/@fortawesome/fontawesome-free/css/all.min.css" type="text/css">
<!-- Page plugins -->
<!-- Argon CSS -->
<link rel="stylesheet" href="/assets/css/argon.css?v=1.2.0" type="text/css">
<link rel="stylesheet" href="/assets/vendor/dataTables-bs4/css/dataTables.bootstrap4.min.css" type="text/css">
