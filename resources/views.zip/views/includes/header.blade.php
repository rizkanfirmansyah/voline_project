<!DOCTYPE html>
<html>

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="Start your development with a Dashboard for Bootstrap 4.">
  <meta name="author" content="Creative Tim">
  <title>Voline - Vaksin On Line</title>
  <meta name="csrf-token" data-token="{{ csrf_token() }}">

  @include('includes.css')

</head>


<body>

