@include('includes.header')

@include('includes.sidebar')

@include('includes.topbar')

@include('includes.navbar')

@yield('main')

@include('includes.footer')
